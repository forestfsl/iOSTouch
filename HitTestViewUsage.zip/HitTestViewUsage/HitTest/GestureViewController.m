//
//  GestureViewController.m
//  HitTestViewDemo
//
//  Created by admin on 2018/9/13.
//  Copyright © 2018 Lemons. All rights reserved.
//


//https://www.jianshu.com/p/c294d1bd963d?utm_campaign=maleskine&utm_content=note&utm_medium=seo_notes&utm_source=recommendation

#import "GestureViewController.h"

@interface GestureViewController ()

@end

@implementation GestureViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    //为view添加一个单击的绑定手势
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(actionTapView)];
    [self.view addGestureRecognizer:tap];
    
//    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(didClickGes)];
//    [self.clickBtn addGestureRecognizer:tap1];
    [self.clickBtn addTarget:self action:@selector(didClickBtn) forControlEvents:UIControlEventTouchUpInside];
}

- (void)actionTapView{
    NSLog(@"backView taped");
}

- (void)didClickGes{
    NSLog(@"a按钮手势");
}
- (void)didClickBtn{
    NSLog(@"按钮被点击了");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 20;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.textLabel.text = @"有本事点我";
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"cell didSelect");
}

@end
