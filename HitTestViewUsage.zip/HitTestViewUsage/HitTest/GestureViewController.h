//
//  GestureViewController.h
//  HitTestViewDemo
//
//  Created by admin on 2018/9/13.
//  Copyright © 2018 Lemons. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HitTableView.h"
#import "HitTableViewButton.h"

@interface GestureViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet HitTableViewButton *clickBtn;

@property (weak, nonatomic) IBOutlet HitTableView *tableView;
@end
