//
//  HitTableViewButton.m
//  HitTestViewDemo
//
//  Created by admin on 2018/9/13.
//  Copyright © 2018 Lemons. All rights reserved.
//

#import "HitTableViewButton.h"

@implementation HitTableViewButton


- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    NSLog(@"进入HitTableViewButton---hitTest withEvent ---");
    UIView * view = [super hitTest:point withEvent:event];
    NSLog(@"离开HitTableViewButton---hitTest withEvent ---hitTestView:%@",view);
    return view;
}

- (BOOL)pointInside:(CGPoint)point withEvent:(nullable UIEvent *)event {
    NSLog(@"HitTableViewButton---pointInside withEvent ---");
    BOOL isInside = [super pointInside:point withEvent:event];
    NSLog(@"HitTableViewButton---pointInside withEvent --- isInside:%d",isInside);
    return isInside;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"HitTableViewButton_touchesBegan");
     [super touchesBegan:touches withEvent:event];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event {
    NSLog(@"HitTableViewButton_touchesMoved");
    [super touchesMoved:touches withEvent:event];

}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event {
    NSLog(@"HitTableViewButton_touchesEnded");
    [super touchesEnded:touches withEvent:event];

}


//记住，如果这里面不调用super 方法的话，事件的传递链将不会继续传递下去，导致最终按钮target-action响应不了

@end
