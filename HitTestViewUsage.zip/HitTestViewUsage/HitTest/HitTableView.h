//
//  HitTableView.h
//  HitTestViewDemo
//
//  Created by admin on 2018/9/13.
//  Copyright © 2018 Lemons. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HitTableView : UITableView

@end
